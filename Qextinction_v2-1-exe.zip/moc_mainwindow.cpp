/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created: Fri 4. Jan 12:24:04 2013
**      by: The Qt Meta Object Compiler version 63 (Qt 4.8.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../Qextinction_V2-1/mainwindow.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_MainWindow[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
      16,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: signature, parameters, type, tag, flags
      12,   11,   11,   11, 0x05,

 // slots: signature, parameters, type, tag, flags
      30,   11,   11,   11, 0x0a,
      46,   11,   11,   11, 0x0a,
      56,   11,   11,   11, 0x0a,
      74,   11,   11,   11, 0x0a,
      96,   11,   11,   11, 0x0a,
     109,   11,   11,   11, 0x0a,
     125,   11,   11,   11, 0x0a,
     154,  149,   11,   11, 0x0a,
     187,   11,   11,   11, 0x2a,
     216,  149,   11,   11, 0x0a,
     231,   11,   11,   11, 0x2a,
     242,   11,   11,   11, 0x0a,
     264,   11,   11,   11, 0x0a,
     281,   11,   11,   11, 0x0a,
     305,   11,   11,   11, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_MainWindow[] = {
    "MainWindow\0\0arretOrdinateur()\0"
    "ouvrirAPropos()\0quitter()\0boutonStartStop()\0"
    "actualisationQLabel()\0boucleTest()\0"
    "testProgramme()\0actualisatonDateHeure()\0"
    "etat\0EtatBoutonDockStartAndStop(bool)\0"
    "EtatBoutonDockStartAndStop()\0"
    "EtatDock(bool)\0EtatDock()\0"
    "affichageSauvegarde()\0enregistrement()\0"
    "effacerEnregistrement()\0lectureSauvegarde()\0"
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        MainWindow *_t = static_cast<MainWindow *>(_o);
        switch (_id) {
        case 0: _t->arretOrdinateur(); break;
        case 1: _t->ouvrirAPropos(); break;
        case 2: _t->quitter(); break;
        case 3: _t->boutonStartStop(); break;
        case 4: _t->actualisationQLabel(); break;
        case 5: _t->boucleTest(); break;
        case 6: _t->testProgramme(); break;
        case 7: _t->actualisatonDateHeure(); break;
        case 8: _t->EtatBoutonDockStartAndStop((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 9: _t->EtatBoutonDockStartAndStop(); break;
        case 10: _t->EtatDock((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 11: _t->EtatDock(); break;
        case 12: _t->affichageSauvegarde(); break;
        case 13: _t->enregistrement(); break;
        case 14: _t->effacerEnregistrement(); break;
        case 15: _t->lectureSauvegarde(); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData MainWindow::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject MainWindow::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_MainWindow,
      qt_meta_data_MainWindow, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &MainWindow::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow))
        return static_cast<void*>(const_cast< MainWindow*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 16)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 16;
    }
    return _id;
}

// SIGNAL 0
void MainWindow::arretOrdinateur()
{
    QMetaObject::activate(this, &staticMetaObject, 0, 0);
}
QT_END_MOC_NAMESPACE
