/* Qextinction / mainwindows.cpp
   Copyright (C) 2012 Pierre Leroux

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.*/

#include "mainwindow.h"

MainWindow::MainWindow(QWidget *parent)     //CONSTRUCTEUR
    : QMainWindow(parent)
{

    //parametrage nom appli pour QSetting
    QCoreApplication::setApplicationName("Qextinction");
    QCoreApplication::setApplicationVersion("2.1");
    QCoreApplication::setOrganizationName("PierreLeroux");


    //Modification fenetre
    setWindowTitle("Qextinction");
    setMinimumSize(250, 250);
    setMaximumSize(500, 500);
    setWindowIcon(QIcon("images/Shutdown.png"));
    //qDebug() << QCoreApplication::applicationDirPath();

    fenetreOption = new option();
    dock = new dockReglages("Reglages");    //placer ici, car initialtisation variables dans readSettings
    readSetting();  //lecture de la position et de la taille de la fen�tre

    //cr�ation du d�compte Qlabel principal dans la QMainWindows
    m_decompte = new QLabel(this);
    m_decompte->setTextFormat(Qt::RichText);
    m_decompte->setText("<p>D�compte :</p><p>Aucun d�compte avant l'�xtinction</p><p>Cliquez sur r�glages</p>");
    m_decompte->setAlignment(Qt::AlignCenter);

    //ajout d'un qwidget car mainWindows
    setCentralWidget(m_decompte);

    //creation Action
    actionQuitter = new QAction(QIcon("images/Log_Out.png") ,"Quitter", this);  //initialinisation
    actionQuitter->setShortcut(QKeySequence(QKeySequence("Ctrl+Q")));           //raccourci clavier
    actionQuitter->setStatusTip("Fermer Qextinction maintenant");               //message d'information en bas de la fen�tre (statusBar)
    connect(actionQuitter, SIGNAL(triggered()), this, SLOT(quitter()));         //connect

    actionReglages = new QAction(QIcon("images/setting.png") ,"R�glages", this);
    actionReglages->setShortcut(QKeySequence("Ctrl+R"));
    actionReglages->setStatusTip("Ouvrir la fen�tre des r�glages");
    connect(actionReglages, SIGNAL(triggered()), fenetreOption, SLOT(exec()));

    actionAbout = new QAction("A propos", this);
    actionAbout->setStatusTip("Ouvrir la fen�tre A propos");
    connect(actionAbout, SIGNAL(triggered()), this, SLOT(ouvrirAPropos()));

    actionAboutQt = new QAction("A propos de Qt", this);
    actionAboutQt->setStatusTip("Ouvrir la fen�tre A propos de Qt");
    connect(actionAboutQt, SIGNAL(triggered()), qApp, SLOT(aboutQt()));

    actionStartAndStop = new QAction(QIcon("images/start.png"), "Start", this);
    actionStartAndStop->setShortcut(QKeySequence("Ctrl+D"));
    actionStartAndStop->setStatusTip("D�marrer le d�compte");
    connect(actionStartAndStop, SIGNAL(triggered()), this, SLOT(boutonStartStop()));

    actionEtatBoutonDockStartAndStop = new QAction("fermer le dock", this);
    connect(actionEtatBoutonDockStartAndStop, SIGNAL(triggered()), this, SLOT(EtatBoutonDockStartAndStop()));

    actionEtatDock = new QAction("fermer le dock", this);
    connect(actionEtatDock, SIGNAL(triggered()), this, SLOT(EtatDock()));

    actionEnregistrement = new QAction(QIcon("images/save-as.png"), "Enregistrer", this);
    actionEnregistrement->setStatusTip("Sauvegarder");
    actionEnregistrement->setShortcut(QKeySequence("Ctrl+S"));
    connect(actionEnregistrement, SIGNAL(triggered()), this, SLOT(enregistrement()));

    //creation menu
    menuFichier = menuBar()->addMenu("Fichier");
    menuFichier->addAction(actionStartAndStop);
    menuFichier->addSeparator();
    menuSauvegarde = menuFichier->addMenu("Sauvegarde");
    lectureSauvegarde();
    menuFichier->addAction(actionEnregistrement);
    menuFichier->addSeparator();
    menuFichier->addAction(actionQuitter);

    menuOption = menuBar()->addMenu("Option");
    menuOption->addAction(actionReglages);

    MenuAffichage = menuBar()->addMenu("Affichage");
    QMenu *afficherDockBouton = MenuAffichage->addMenu("dock bouton start ou stop");
    afficherDockBouton->addAction(actionEtatBoutonDockStartAndStop);
    QMenu *afficherDock = MenuAffichage->addMenu("dock R�glages");
    afficherDock->addAction(actionEtatDock);

    menuAide = menuBar()->addMenu("Aide");
    menuAide->addAction(actionAbout);
    menuAide->addAction(actionAboutQt);

    //cr�ation toolbar
    toolBarPrincipal = addToolBar("Fichier");
    toolBarPrincipal->addAction(actionStartAndStop);
    toolBarPrincipal->addSeparator();
    toolBarPrincipal->addAction(actionReglages);
    toolBarPrincipal->addSeparator();
    toolBarPrincipal->addAction(actionEnregistrement);
    toolBarPrincipal->addSeparator();
    toolBarPrincipal->addAction(actionQuitter);

    dateHeureStatusBar = new QLabel(this);  //Init QLabel pour affichage de la date et de l'heure

    //cretion dock bouton Start And Stop
    boutonDockStartAndStop = new QPushButton(QIcon("images/start.png"), "START", this);
    boutonDockStartAndStop->setStatusTip("D�marrer le d�compte");
    connect(boutonDockStartAndStop, SIGNAL(clicked()), this, SLOT(boutonStartStop()));

    dockBoutonStartAndStop = new QDockWidget("Bouton Start And Stop", this);
    dockBoutonStartAndStop->setWidget(boutonDockStartAndStop);
    dockBoutonStartAndStop->setFeatures(QDockWidget::DockWidgetMovable | QDockWidget::DockWidgetFloatable);

    //dock = new dockReglages("Reglages");  //placer en haut de la fenetre
    connect(dock, SIGNAL(modificationDock()), this, SLOT(actualisationQLabel()));

    addDockWidget(Qt::BottomDockWidgetArea, dockBoutonStartAndStop);
    addDockWidget(Qt::RightDockWidgetArea, dock);

    //cr�ation statusBar
    statusBar()->showMessage("pr�t");
    statusBar()->addPermanentWidget(dateHeureStatusBar);
    actualisatonDateHeure();
    connect(interuptionSecondeStatutBar, SIGNAL(timeout()), this, SLOT(actualisatonDateHeure()));

    EtatBoutonDockStartAndStop(true);
    EtatDock(true);

    m_bloquageDecompte = false; //init booleen bloquage fenetre lors du decompte

    m_ouvertureReglage = false; //renitialisation du d�compte lors de la r�ouverture de la fentre r�glages

    m_dateInscrit = new QDate;  //Comparaison date lors du test toutes les secondes
    m_heureInscrit = new QTime; //Comparaison heure lors du test toutes les secondes

    m_Interuption1S = new QTimer(this); //d�claration timer principale du programme
    connect(m_Interuption1S, SIGNAL(timeout()), this, SLOT(boucleTest()));   // connect boucle de test active toute les secondes

    connect(this, SIGNAL(arretOrdinateur()), this, SLOT(testProgramme()));  //connect slot d'action finale du programme pour la fermeture de WINDOWS

    //connect(this, SIGNAL(actualisationEnregistrement()), this, SLOT(lectureSauvegarde()));

}

MainWindow::~MainWindow()   //DESTRUCTEUR
{

}

void MainWindow::enregistrement()   //slots
{
    qDebug() << "enregistrement";

    QDialog *fenetreDemandeNomFichier = new QDialog(this, Qt::WindowCloseButtonHint);

    fenetreDemandeNomFichier->setWindowTitle("Enregistrement");
    fenetreDemandeNomFichier->setFixedSize(200, 100);

    QVBoxLayout *fond = new QVBoxLayout();
    QLabel *titre = new QLabel("Entrer le nom du fichier : ");
    QLineEdit *texte = new QLineEdit();
    texte->setMaxLength(20);
    QPushButton *bouttonValider = new QPushButton("Valider");
    bouttonValider->setShortcut(QKeySequence("enter"));
    connect(bouttonValider, SIGNAL(clicked()), fenetreDemandeNomFichier, SLOT(close()));
    QHBoxLayout *layoutBoutton = new QHBoxLayout();

    layoutBoutton->addStretch();
    layoutBoutton->addWidget(bouttonValider);

    fond->addWidget(titre);
    fond->addWidget(texte);
    fond->addLayout(layoutBoutton);

    fenetreDemandeNomFichier->setLayout(fond);

    if(fenetreDemandeNomFichier->exec() == 0)   //quand fenetre demande du nom est ferm�e
    {

        for(int i(0); i < 10; i++)
        {
            qDebug() << i;
            QSettings settings; //Appel � chaque utilisation

            QString stringGroupe, valeur;
            valeur.setNum(i);
            stringGroupe = "sauvegarde" + valeur;
            qDebug() << stringGroupe;

            settings.beginGroup(stringGroupe);

            if(settings.value("enregistrer", false).toBool() == false)  //sauvegarde toutes les valeurs entr�e
            {
                qDebug() << "enregistrement sauvegarde";
                qDebug() << settings.value("enregistrer", false).toBool();

                if(texte->text() == "") break;
                settings.setValue("enregistrer", true);
                settings.setValue("affichageNom", texte->text());
                settings.setValue("dateTime", QDateTime::currentDateTime());
                settings.setValue("horaire", dock->setHoraire());
                settings.setValue("minuterH", dock->setMinuterH());
                settings.setValue("minuterM", dock->setMinuterM());
                settings.setValue("minuterS", dock->setMinuterS());
                settings.setValue("horaireChecked", dock->isHoraireChecked());
                settings.setValue("minuterChecked", dock->isMinuterChecked());

                settings.endGroup();

                break;
            }
            else if(i == 9)
            {
                QMessageBox::warning(this, "Erreur", "Un maximun de 10 sauvegardes peut �tre enregistr�e");
            }
        }
    }

    //emit actualisationEnregistrement();
}

void MainWindow::lectureSauvegarde()    //slots //lit les sauvegardes � l'ouverture du programme
{
    QAction *actionSauvegarde[10];

    for(int i(0); i < 10; i++)
    {
        QSettings settings; //Appel � chaque utilisation

        QString stringGroupe, valeur;
        valeur.setNum(i);
        stringGroupe = "sauvegarde" + valeur;
        qDebug() << stringGroupe;

        settings.beginGroup(stringGroupe);

        if(settings.value("enregistrer", false).toBool())   //si il y a une sauvegarde (true)
        {
            QString lectureNom;
            lectureNom = settings.value("affichageNom").toString(); //afficher le non

            qDebug() << lectureNom;

            actionSauvegarde[i] = new QAction(lectureNom, this);
            menuSauvegarde->addAction(actionSauvegarde[i]);
            connect(actionSauvegarde[i], SIGNAL(triggered()), this, SLOT(affichageSauvegarde()));   //cr�e action // cr�e connect
        }
        else
        {
            if(i == 0)
            {
                QAction *aucuneSauvegarde = new QAction("Aucune Sauvegarde", this); //else aucune sauvegarde
                menuSauvegarde->addAction(aucuneSauvegarde);
            }
            else
            {
                break;
            }
        }
        settings.endGroup();
    }
    QAction *actionEffacer = new QAction("ToutEffacer", this);
    connect(actionEffacer, SIGNAL(triggered()), this, SLOT(effacerEnregistrement()));
    menuSauvegarde->addSeparator();
    menuSauvegarde->addAction(actionEffacer);
}

void MainWindow::effacerEnregistrement()
{
    for(int i(0); i < 10; i++)
    {
        QSettings settings; //Appel � chaque utilisation

        QString stringGroupe, valeur;
        valeur.setNum(i);
        stringGroupe = "sauvegarde" + valeur;

        settings.beginGroup(stringGroupe);

        settings.setValue("enregistrer", false);    //met false

        settings.endGroup();
    }
    //emit actualisationEnregistrement();
}

void MainWindow::affichageSauvegarde()    //slots
{
    QSettings settings; //Appel � chaque utilisation

    QAction *action = qobject_cast<QAction *>(sender());    //recuper le pointeur de l'action sender

    for(int i(0); i < 10; i++)
    {
        QString stringGroupe, valeur;
        valeur.setNum(i);
        stringGroupe = "sauvegarde" + valeur;

        settings.beginGroup(stringGroupe);

        if(settings.value("affichageNom").toString() == action->text()) //test si les deux ont le m�me nom
        {
            //affiche dans le dock reglages
            dock->mettreHoraire(settings.value("horaire").value<QDateTime>());
            dock->mettreMinuterH(settings.value("minuterH").toInt());
            dock->mettreMinuterM(settings.value("minuterM").toInt());
            dock->mettreMinuterS(settings.value("minuterS").toInt());
            dock->mettreHoraireChecked(settings.value("horaireChecked").toBool());
            dock->mettreMinuterChecked(settings.value("minuterChecked").toBool());

            break;
        }
        settings.endGroup();
    }
}

void MainWindow::actualisationQLabel()
{
    if(!m_bloquageDecompte) //si aucun blocage du decompte la fenetre s'ouvre
    {

        if(dock->isHoraireChecked()) //si c'est horaire
        {
            QString s1, s2;         // mise en forme
            QDateTime dt1, dt2;
            dt1 = dock->setHoraire();    //recuperation de l'objet
            *m_dateInscrit = dt1.date();            //recuperation de la date
            s1 = m_dateInscrit->toString("dd.MM.yyyy"); //Mise en forme string
            dt2 = dock->setHoraire();    //recuperation de l'objet
            *m_heureInscrit = dt2.time();            //recuperation de l'heure
            s2 = m_heureInscrit->toString("hh:mm:ss");  //Mise en forme string
            QString st;
            st = "<p>D�compte Horaire: </p><p><h3>" + s1 + " " + s2 +"</h3></p><p>Cliquez sur START ou STOP</p>";
            m_decompte->setText(st);        //inscription dans le QLabel principale
        }
        else if(dock->isMinuterChecked())    //si c'est le minuteur
        {
            QString s3;
            QTime d2(dock->setMinuterH(), dock->setMinuterM(), dock->setMinuterS()); //mise en forme QTime avec les valeur entrer dans la fenetre reglages
            s3 = d2.toString("hh:mm:ss");   //Mise en forme string
            QString st2;
            st2 = "<p>D�compte Minut�: </p><p><h3>" + s3 +"</h3></p><p>Cliquez sur START</p>";
            m_decompte->setText(st2);   //inscription dans le QLabel principale
        }
        m_ouvertureReglage = true;  //reset du decompte lors de l'ouverture reglage
    }
}

void MainWindow::EtatBoutonDockStartAndStop(bool etat)       //slots    //ouvre ou ferme le dock
{
    if(!isActivateDockButton)
    {

        if(etat)    //etat false lors du premier appel
        {
            boutonDockStartAndStop->hide();
            dockBoutonStartAndStop->hide();

            actionEtatBoutonDockStartAndStop->setText("Ouvrir le dock");

            isActivateDockButton = false;
        }
        else
        {
            actionEtatBoutonDockStartAndStop->setText("Fermer le dock");
            boutonDockStartAndStop->show();
            dockBoutonStartAndStop->show();

            isActivateDockButton = true;
        }
    }
    else
    {

        if(etat)
        {
            actionEtatBoutonDockStartAndStop->setText("Fermer le dock");
            boutonDockStartAndStop->show();
            dockBoutonStartAndStop->show();

            isActivateDockButton = true;
        }
        else
        {
            boutonDockStartAndStop->hide();
            dockBoutonStartAndStop->hide();

            actionEtatBoutonDockStartAndStop->setText("Ouvrir le dock");

            isActivateDockButton = false;
        }
    }

}

void MainWindow::EtatDock(bool etat)    //slots     //ouvre ou ferme le dock
{
    if(!isActivateDock)
    {

        if(etat)    //etat false lors du premier appel
        {
            dock->hide();

            actionEtatDock->setText("Ouvrir le dock");

            isActivateDock = false;
        }
        else
        {
            actionEtatDock->setText("Fermer le dock");

            dock->show();

            isActivateDock = true;
        }
    }
    else
    {

        if(etat)
        {
            actionEtatDock->setText("Fermer le dock");

            dock->show();

            isActivateDock = true;
        }
        else
        {

            dock->hide();

            actionEtatDock->setText("Ouvrir le dock");

            isActivateDock = false;
        }
    }

}

void MainWindow::readSetting()  //m�thode private
{
    QSettings settings; //Appel � chaque utilisation

    settings.beginGroup("mainWindows"); //groupe mainWindows pour retrouver different parametre par groupe
    resize(settings.value("size", QSize(250, 250)).toSize());
    move(settings.value("pos", QPoint(200, 200)).toPoint());
    restoreGeometry(settings.value("geometry").toByteArray());
    restoreState(settings.value("state").toByteArray());
    isActivateDockButton = settings.value("activateDockBoutonStartAndStop").toBool();
    isActivateDock = settings.value("activateDock").toBool();
    settings.endGroup();    //ne pas oublier!!!

    if(fenetreOption->isOptionCheckBoxActivateAffichageDock())  //si checked dans option
    {
        //affiche au demarrage les valeurs de l'ancienne fermeture du programme
        settings.beginGroup("dock");
        dock->mettreHoraire(settings.value("horaire").value<QDateTime>());
        dock->mettreMinuterH(settings.value("M_h").toInt());
        dock->mettreMinuterM(settings.value("M_m").toInt());
        dock->mettreMinuterS(settings.value("M_s").toInt());
        dock->mettreHoraireChecked(settings.value("horaireChecked").toBool());
        dock->mettreMinuterChecked(settings.value("minuterChecked").toBool());
        settings.endGroup();
    }

}

void MainWindow::writeSetting() //m�thode private
{
    QSettings settings; //Appel � chaque utilisation

    settings.beginGroup("mainWindows");
    settings.setValue("size", size());
    settings.setValue("pos", pos());
    settings.setValue("geometry", saveGeometry());
    settings.setValue("state", saveState());
    settings.setValue("activateDockBoutonStartAndStop", isActivateDockButton);
    settings.setValue("activateDock", isActivateDock);
    settings.endGroup();

    //enregistre les valeurs pour affich�e au demarrage les valeurs de l'ancienne fermeture du programme
    settings.beginGroup("dock");
    settings.setValue("horaire", dock->setHoraire());
    settings.setValue("M_h", dock->setMinuterH());
    settings.setValue("M_m", dock->setMinuterM());
    settings.setValue("M_s", dock->setMinuterS());
    settings.setValue("HoraireChecked", dock->isHoraireChecked());
    settings.setValue("MinuterChecked", dock->isMinuterChecked());
    settings.endGroup();
}

void MainWindow::actualisatonDateHeure()    //slot  //date et heure dans la statusBar
{
    interuptionSecondeStatutBar = new QTimer(this); //creation QTimer
    interuptionSecondeStatutBar->start(1000);

    QDate dateActuel = QDate::currentDate();
    QTime heureActuel = QTime::currentTime();

    QString s1, s2, st;
    s1 = dateActuel.toString("dd/MM/yyyy");
    s2 = heureActuel.toString("hh:mm:ss");

    st = s1 + " " + s2;
    dateHeureStatusBar->setText(st);    //affichage dans le QLabel pour affichage dans la status bar
}

void MainWindow::ouvrirAPropos()    //slots
{
    QDialog *APropos = new QDialog(this, Qt::WindowCloseButtonHint);
    APropos->setFixedSize(300, 200);
    APropos->setWindowTitle("A Propos de Qextinction");

    QTabWidget *tab = new QTabWidget(APropos);      //QTABWIDGET incluant un QLabel et deux QTextEdit
    tab->setGeometry(5, 5, 290, 190);

    QLabel *infos = new QLabel(APropos);
    infos->setTextFormat(Qt::RichText); //format texte RTF
    infos->setText("<P><h3>Qextinction</h3></p><p>Cr�er par Pierre Leroux</p><p>Compil� le 31/12/2012<p><p>Version 2.1</p>");
    infos->setAlignment(Qt::AlignCenter);

    QTextEdit *Alire = new QTextEdit(APropos);
    Alire->setText("Ce programme est fournit � EN L'�TAT �, SANS GARANTIE D'AUCUNE SORTE, INCLUANT, SANS S'Y LIMITER, LES GARANTIES D'ABSENCE DE D�FAUT, DE QUALIT� MARCHANDE, D'AD�QUATION � UN USAGE PARTICULIER.");
    Alire->setReadOnly(true);

    QTextEdit *licence = new QTextEdit(APropos);
    licence->setText("<p>This program is free software: you can redistribute it and/or modify"
                     "it under the terms of the GNU General Public License as published by"
                     "the Free Software Foundation, either version 3 of the License, or"
                     "(at your option) any later version."
                     "This program is distributed in the hope that it will be useful,"
                     "but WITHOUT ANY WARRANTY; without even the implied warranty of"
                     "MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the"
                     "GNU General Public License for more details."
                     "You should have received a copy of the GNU General Public License"
                     "along with this program. If not, see http://www.gnu.org/licenses/.</p>");

    licence->setReadOnly(true);

    tab->addTab(infos, "Information");
    tab->addTab(Alire, "A lire");
    tab->addTab(licence, "GNU General Public License");

    APropos->exec();    //ouverture de la fenetre
}

void MainWindow::quitter()  //slots
{
    if(!m_bloquageDecompte)
    {
        writeSetting();
        exit(0);    //si aucun blocage du decompte fermture fenetre
    }
    else {ouvrirMessageBoxBlocageDecompte();} //sinon ouvre le message box
}

void MainWindow::closeEvent(QCloseEvent *even)
{
    if(!m_bloquageDecompte)
    {
        writeSetting();
        even->accept(); //si aucun blocage du decompte fermture de la fenetre par le pointeur enven
    }
    else
    {
        ouvrirMessageBoxBlocageDecompte();  //sinon ouvre la message box
        even->ignore();
    }
}

void MainWindow::ouvrirMessageBoxBlocageDecompte()
{
    message = new QMessageBox(this);
    message->information(this, "Erreur Fermeture", "Veuillez Appuyer sur le bouton STOP avant la fermeture de Qextinction");
}

void MainWindow::boucleTest()   //fonction principale //slots
{
    //config action Start Stop                                                                                                                   //!!!
    actionStartAndStop->setIcon(QIcon("images/stop-red.png"));
    actionStartAndStop->setShortcut(QKeySequence("Ctrl+A"));
    actionStartAndStop->setText("Stop");
    actionStartAndStop->setStatusTip("Arr�te le d�compte");

    //config du bouton dans le dock Start And Stop
    boutonDockStartAndStop->setIcon(QIcon("images/stop-red.png"));
    boutonDockStartAndStop->setText("STOP");
    boutonDockStartAndStop->setStatusTip("Arr�te le d�compte");

    m_bloquageDecompte = true;  //blocage du decompte par true car cela bloque la fermeture et ouverture reglages

    m_Interuption1S->start(1000);   //demmarre les 1s de delay puis reappelle de la boucle test par connect timeout dans le constructeur

    qDebug() << "acc�es fonction boucle TEST";

    if(dock->isHoraireChecked())
    {
        QDate dateActuel = QDate::currentDate();
        QTime heureActuel = QTime::currentTime();
        if(dateActuel <= *m_dateInscrit && heureActuel <= *m_heureInscrit) //si plus petit ou �gale
        {
            qDebug() << "passer" << m_dateInscrit->toString("dd.MM.yyyy") << dateActuel.toString("dd.MM.yyyy") << m_heureInscrit->toString("hh:mm:ss") << heureActuel.toString("hh:mm:ss");
            if(dateActuel == *m_dateInscrit) //si date correct
            {

                qDebug() << "date correct";
                qDebug() << *m_heureInscrit;
                qDebug() << heureActuel;
                if(heureActuel.addSecs(-1) == *m_heureInscrit) // puis si heure correct
                    // prb heure actuel et inscrit �gaux mais la condition ne s'active pas ?
                {
                    qDebug() << "heure correct";
                    m_bloquageDecompte = false; //aucun blocage pour pouvoir fermer l'application par l'ordinateur
                    emit arretOrdinateur(); //signal arretOrdinateur connect a testProgramme
                }
                      // passage programme ne fonctionnant pas
                    // je ne comprend pas pourquoi
                    // tester de nombreuse fois avec des qDebug

                heureActuel.addSecs(-1);    //suppression d'une seconde car on atteint jammais l'heure actuel
                if(heureActuel.second() == m_heureInscrit->second() && heureActuel.minute() == m_heureInscrit->minute() && heureActuel.hour() == m_heureInscrit->hour())
                {
                    qDebug() << "heure correct";
                    m_bloquageDecompte = false; //aucun blocage pour pouvoir fermer l'application par l'ordinateur
                    emit arretOrdinateur(); //signal arretOrdinateur connect a testProgramme
                }   //fonctionnement correct par cette m�thode !

            }
        }
    }
    else if(dock->isMinuterChecked())
    {
        static QTime reference(0, 0, 0);    //declaration static car appeler toute les secondes
        static QTime HeureRestant(dock->setMinuterH(), dock->setMinuterM(), dock->setMinuterS());

        if(m_ouvertureReglage)  //reset du test si modification reglage exticntion minut�e
        {
            HeureRestant.setHMS(dock->setMinuterH(), dock->setMinuterM(), dock->setMinuterS());
        }

        if(HeureRestant != reference)   //heure restant pas �gale � 0
        {
            HeureRestant = HeureRestant.addSecs(-1);    //suppression d'une secondes

            QString s;  //mise en forme
            s = HeureRestant.toString("hh:mm:ss");
            QString st2;
            st2 = "<p>D�compte Minut�: </p><p><h3>" + s +"</h3></p><p>Cliquez sur STOP pour arret�</p>";
            m_decompte->setText(st2);   //inscription dans le QLabel principale

            if(HeureRestant == reference)   //test maintenant de l'heure si �gale � 0
            {
                m_bloquageDecompte = false; //aucun blocage pour pouvoir fermer l'application par l'ordinateur
                emit arretOrdinateur(); //signal arretOrdinateur connect a testProgramme
            }
        }

        m_ouvertureReglage = false; //aucun blocage pour pouvoir fermer l'application par l'ordinateur
    }
}

void MainWindow::boutonStartStop()  //slots //appel lors de chache appui du bouton
{
    if(!m_bloquageDecompte) //si aucun blocage appel boucle test // par defaut lors de l'ouverture du programme
        boucleTest();
    else    //si arret decompte
      {
        //config action Start And Stop  //inscrption start pour recommencer le d�comtpe
        actionStartAndStop->setIcon(QIcon("images/start.png"));
        actionStartAndStop->setShortcut(QKeySequence("Ctrl+D"));
        actionStartAndStop->setText("Start");
        actionStartAndStop->setStatusTip("d�marre le d�compte");

        //config du bouton dans le dock Start And Stop
        boutonDockStartAndStop->setIcon(QIcon("images/start.png"));
        boutonDockStartAndStop->setText("START");
        boutonDockStartAndStop->setStatusTip("D�marrer le d�compte");

        m_bloquageDecompte = false; //aucun blocage pour pouvoir fermer l'application
        m_Interuption1S->stop();    //arret timer car decompte stop�e
      }
}

void MainWindow::testProgramme()    //slots finale du programme
{
    qDebug() << "Extinction";

    QSettings settings;

    if(settings.value("PageOption/lireSon", false).toBool())    //son activer dans la fenetre option
    {
        QSound::play(settings.value("PageOption/cheminLectureSon").toString());
    }

    //system("shutdown /p");    //commande system d'exticntion totale de l'ordinateur sans delai et sans message d'alerte

    switch(fenetreOption->choixExtinction())
    {
    case option::redemarrage :
        system("shutdown /r");
        qDebug() << "redemarrage";
        break;
    case option::arret :
        system("shutdown /s");
        qDebug() << "arret";
        break;
    case option::arretForce :
        system("shutdown /p");
        qDebug() << "arret Forcer";
        break;
    case option::veilleProlonge :
        system("shutdown /k");
        qDebug() << "veille prolonger";
        break;
    default :
        system("shutdown /p");
        qDebug() << "default";
        break;
    }
}
