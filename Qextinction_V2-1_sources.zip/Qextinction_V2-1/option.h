/* Qextinction / option.h
   Copyright (C) 2012 Pierre Leroux

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.*/

#ifndef OPTION_H
#define OPTION_H

#include <QDialog>
#include "inclusion.h"
#include "reglages.h"

class option : public QDialog
{
    Q_OBJECT

public:
    explicit option(QWidget *parent = 0);

    enum TypeExtinction{redemarrage, arret, arretForce, veilleProlonge};

   TypeExtinction choixExtinction();

   //ascesseur
   bool isOptionCheckBoxActivateAffichageDock();

protected:
    void closeEvent(QCloseEvent *even); //virtual fonction

signals:
    /*
      Signal emit pour une actualisation du tableau sauvegarde
    */
    void actualisationSignal(bool etat);
    
public slots:
    void ChangementNomItem(int ligne, int colonne);
    void supprimerItem(int ligne, int colonne);
    void OuvertureReglages(int ligne, int colonne);
    void actualisationSlots(bool etat);
    void lectureCheminSon();
    void lectureCheminSonQlineEdit(QString chemin);

private:

    QTabWidget *m_tab;

    //Option d'extinction du programme
    void PageExtinctionProgramme();
    QWidget *m_pageExtinctionProgramme;   //widget conteneurs principal
    QRadioButton *m_redemarrage;
    QRadioButton *m_arret;
    QRadioButton *m_arretForce;
    QRadioButton *m_veilleProlonge;
    QGroupBox *m_choixExtinction;
    QVBoxLayout *layoutRadioButton;

    //pages option
    void PageOption();
    QWidget *m_pageOption;
    QVBoxLayout *fondPageOption;
    QLabel *m_affichageVariablesDock;
    QGroupBox *m_groupActiverAffichage;
    QLabel *m_labelSon;
    QLineEdit *m_cheminSon;
    QToolButton *m_ouvrirFenetreCheminSon;
    QGroupBox *m_groupSon;

    //pages sauvegarde
    void PageSauvegarde(bool boucle = false);
    QWidget *m_pageSauvegarde;
    QTableWidget *m_tableauSauvegarde;
    QTableWidgetItem *m_sauvegarde[10][5];
    QVBoxLayout *m_fondPageSauvegarde;

    reglages *fenetreModificationReglages;
    
};

#endif // OPTION_H
