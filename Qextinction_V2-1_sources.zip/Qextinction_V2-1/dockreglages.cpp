/* Qextinction / dockreglages.cpp
   Copyright (C) 2012 Pierre Leroux

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.*/

#include "dockreglages.h"

dockReglages::dockReglages(const QString & title, QWidget *parent) : QDockWidget(title, parent)
{
    //label Horaire
    m_infoHoraire = new QLabel(this);
    m_infoHoraire->setTextFormat(Qt::RichText);

    m_infoHoraire->setText("Eteindre le :");

    m_horaire = new QDateTimeEdit(QDateTime::currentDateTime(), this);
    m_horaire->setStatusTip("Date et heure de l'�x�cution");
    connect(m_horaire, SIGNAL(editingFinished()), this, SLOT(enregistrement()));

    //layout Horaire
    QVBoxLayout *layoutHoraireBox = new QVBoxLayout();
    layoutHoraireBox->addWidget(m_infoHoraire);
    layoutHoraireBox->addWidget(m_horaire);

    //construction groupe box Horaire
    m_horaireBox = new QGroupBox("Extinction Horaire", this);
    m_horaireBox->setCheckable(true);   //creation groupbox checkable
    m_horaireBox->setChecked(true);
    m_horaireBox->setLayout(layoutHoraireBox);
    connect(m_horaireBox, SIGNAL(toggled(bool)), this, SLOT(checkedHoraire(bool))); //connect inversion checked groubox les 2

    //Minuter
    m_infoMinuter = new QLabel(this);
    m_infoMinuter->setText("Eteindre dans : ");

    //spin box les 3
    m_h = new QSpinBox(this);
    m_h->setRange(0, 23);   //23H
    m_h->setSuffix(" h");
    m_h->setStatusTip("Decompte des Heures avent l'�x�cution");
    m_m = new QSpinBox(this);
    m_m->setRange(0, 59);   //59M
    m_m->setSuffix(" m");
    m_m->setStatusTip("Decompte des Minutes avent l'�x�cution");
    m_s = new QSpinBox(this);
    m_s->setRange(0, 59);   //59S
    m_s->setSuffix(" s");
    m_s->setStatusTip("Decompte des Secondes avent l'�x�cution");
    connect(m_h, SIGNAL(editingFinished()), this, SLOT(enregistrement()));
    connect(m_m, SIGNAL(editingFinished()), this, SLOT(enregistrement()));
    connect(m_s, SIGNAL(editingFinished()), this, SLOT(enregistrement()));

    m_sliderM = new QSlider(Qt::Horizontal, this);
    m_sliderM->setRange(0, 59);
    m_sliderM->setStatusTip("Slider d'acc�s rapides au decompte des minutes");
    connect(m_sliderM, SIGNAL(valueChanged(int)), m_m, SLOT(setValue(int)));
    connect(m_sliderM, SIGNAL(sliderReleased()), this, SLOT(enregistrement()));

    //layout des 3 spinBox
    QHBoxLayout *layoutSpinBox = new QHBoxLayout;
    layoutSpinBox->addWidget(m_h);
    layoutSpinBox->addWidget(m_m);
    layoutSpinBox->addWidget(m_s);

    //layout de la groupe box
    QVBoxLayout *layoutMinuterBox = new QVBoxLayout();
    layoutMinuterBox->addWidget(m_infoMinuter);
    layoutMinuterBox->addLayout(layoutSpinBox);
    layoutMinuterBox->addWidget(m_sliderM);

    //creation groupeBox
    m_minuterBox = new QGroupBox("Extinction Minut�e", this);
    m_minuterBox->setCheckable(true);   //creation groupboc checkable
    m_minuterBox->setChecked(false);    //non checked car l'autre l'est
    m_minuterBox->setLayout(layoutMinuterBox);
    connect(m_minuterBox, SIGNAL(toggled(bool)), this, SLOT(checkedMinuter(bool))); //connect inversion checked groubox les 2

    QPushButton *m_valider = new QPushButton("Valider", this);
    connect(m_valider, SIGNAL(clicked()), this, SLOT(enregistrement()));

    //layout du fond entre les deux groupbox
    fond = new QVBoxLayout(this);
    fond->addWidget(m_horaireBox);
    fond->addWidget(m_minuterBox);
    fond->addStretch();
    fond->addWidget(m_valider);

    QWidget *widgetFond = new QWidget(this);
    widgetFond->setLayout(fond);

    setWidget(widgetFond);
    setFeatures(QDockWidget::DockWidgetMovable | QDockWidget::DockWidgetFloatable);

    m_setHoraire = new QDateTime(m_horaire->dateTime());    //creation object QDateTime

    m_setMinuterH = 0;  //init attribut
    m_setMinuterM = 0;
    m_setMinuterS = 0;

    m_isHoraireChecked = m_horaireBox->isChecked(); //init attribut booleen selon comment il sont checke les groupbox
    m_isHoraireChecked = m_minuterBox->isChecked();
}

void dockReglages::enregistrement() //slots
{
    *m_setHoraire = m_horaire->dateTime();  //lors de la fermeture inscrit tout les parametre entrer par l'utilisateur dans les attributs.
    m_setMinuterH = m_h->value();
    m_setMinuterM = m_m->value();
    m_setMinuterS = m_s->value();
    m_isHoraireChecked = m_horaireBox->isChecked();
    m_isMinuterChecked = m_minuterBox->isChecked();

    emit modificationDock();
}

void dockReglages::checkedHoraire(bool etatH)   /*slots inversion checked groupbox*/
{m_minuterBox->setChecked(!etatH);}

void dockReglages::checkedMinuter(bool etatM)   /*slots inversion checked groupbox*/
{m_horaireBox->setChecked(!etatM);}

//ascesseur d'acces aux attribut par l'object fenetreReglages dans mainWindows

QDateTime dockReglages::setHoraire() {return *m_setHoraire;}   //renvois un pointeur

int dockReglages::setMinuterH() {return m_setMinuterH;} //remplacer set par is car on accede � sa valeur

int dockReglages::setMinuterM() {return m_setMinuterM;}

int dockReglages::setMinuterS() {return m_setMinuterS;}

bool dockReglages::isHoraireChecked() {return m_isHoraireChecked;}

bool dockReglages::isMinuterChecked() {return m_isMinuterChecked;}

void dockReglages::mettreHoraire(QDateTime horaire)
{
    m_horaire->setDateTime(horaire);
}

void dockReglages::mettreMinuterH(int h)
{
    m_h->setValue(h);
}

void dockReglages::mettreMinuterM(int m)
{
    m_m->setValue(m);
}

void dockReglages::mettreMinuterS(int s)
{
    m_s->setValue(s);
}

void dockReglages::mettreHoraireChecked(bool horaireChecked)
{
    m_horaireBox->setChecked(horaireChecked);
}

void dockReglages::mettreMinuterChecked(bool minuterChecked)
{
    m_minuterBox->setChecked(minuterChecked);
    enregistrement();   //actualisation et enregistrement
}
