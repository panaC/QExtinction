/* Qextinction / inclusion.h
   Copyright (C) 2012 Pierre Leroux

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.*/

#ifndef INCLUSION_H
#define INCLUSION_H

#include <QtGui/QPushButton>
#include <QtGui/QHBoxLayout>
#include <QtGui/QVBoxLayout>
#include <QtGui/QLabel>
#include <QtGui/QWidget>
#include <QtGui/QDialog>
#include <QtGui/QTabWidget>
#include <QtGui/QTextEdit>
#include <QtGui/QGroupBox>
#include <QtGui/QDateTimeEdit>
#include <QtGui/QTimeEdit>
#include <QDateTime>
#include <QTime>
#include <QCloseEvent>
#include <QtGui/QSpinBox>
#include <QApplication>
#include <QtGui/QMessageBox>
#include <QTimer>
#include <QDebug>
#include <QMenuBar>
#include <QAction>
#include <QStatusBar>
#include <QKeySequence>
#include <QToolBar>
#include <QDockWidget>
#include <QSettings>
#include <QSize>
#include <QPoint>
#include <QBitArray>
#include <Qt>
#include <QVariant>
#include <QtGui/QSlider>
#include <QtGui/QRadioButton>
#include <QtGui/QLineEdit>
#include <QtGui/QCheckBox>
#include <QtGui/QTableWidget>
#include <QtGui/QTableWidgetItem>
#include <QStringList>
#include <QSound>
#include <QtGui/QToolButton>
#include <QFileDialog>

#endif // INCLUSION_H
