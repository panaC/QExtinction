/* Qextinction / reglages.h
   Copyright (C) 2012 Pierre Leroux

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.*/

#ifndef REGLAGES_H
#define REGLAGES_H

#include <QDialog>
#include "inclusion.h"

class reglages : public QDialog //h�rite de QDialog
{
    Q_OBJECT

public:
    explicit reglages(QWidget *parent = 0);

    //ascesseur
    QDateTime setHoraire();
    int setMinuterH();
    int setMinuterM();
    int setMinuterS();
    bool isHoraireChecked();
    bool isMinuterChecked();

protected:
    void closeEvent(QCloseEvent *even); //virtual fonction

signals:
    

public slots:
    void checkedHoraire(bool etatH);
    void checkedMinuter(bool etatM);

private:

    //groupbox extinction horaire
    QGroupBox *m_horaireBox;
    QLabel *m_infoHoraire;
    QDateTimeEdit *m_horaire;

    //groupbox extinction minuter
    QGroupBox *m_minuterBox;
    QLabel *m_infoMinuter;
    QSpinBox *m_h;
    QSpinBox *m_m;
    QSpinBox *m_s;

    QPushButton *m_valider;

    //layout de fond vertical
    QVBoxLayout *fond;

    QDateTime *m_setHoraire; //atribut date et horaire entrer par l'utilisateur
    int m_setMinuterH; //atribut minute entr�e par l'utilisateur
    int m_setMinuterM;
    int m_setMinuterS;
    bool m_isHoraireChecked;
    bool m_isMinuterChecked;

    void writeSettings();
    void readSettings();

};

#endif // REGLAGES_H
