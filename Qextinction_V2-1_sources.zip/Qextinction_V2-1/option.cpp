/* Qextinction / option.cpp
   Copyright (C) 2012 Pierre Leroux

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.*/

#include "option.h"

option::option(QWidget *parent) :
    QDialog(parent)
{
    setWindowTitle("Options");
    setWindowIcon(QIcon("images/Shutdown.png"));
    setWindowFlags(Qt::WindowCloseButtonHint);
    setWindowModality(Qt::WindowModal);
    setMinimumSize(200, 200);

    fenetreModificationReglages = new reglages();   //creation object reglages

    m_tab = new QTabWidget(this);   //tab option

    PageExtinctionProgramme();
    PageOption();
    PageSauvegarde();

    QHBoxLayout *fond = new QHBoxLayout(this);
    fond->addWidget(m_tab);

    setLayout(fond);

}

void option::PageExtinctionProgramme()  //fabrication page
{
    QSettings settings;
    settings.beginGroup("pageExtinction");

    m_pageExtinctionProgramme = new QWidget(this);

    m_redemarrage = new QRadioButton("red�marrage", this);
    m_redemarrage->setChecked(settings.value("redemarrage", false).toBool());
    m_arret = new QRadioButton("arret", this);
    m_arret->setChecked(settings.value("arret", true).toBool());
    m_arretForce = new QRadioButton("arret forc�", this);
    m_arretForce->setChecked(settings.value("arretForce", false).toBool());
    m_veilleProlonge = new QRadioButton("veille prolonger", this);
    m_veilleProlonge->setChecked(settings.value("veilleProlonge", false).toBool());

    layoutRadioButton = new QVBoxLayout(this);
    layoutRadioButton->addWidget(m_redemarrage);
    layoutRadioButton->addWidget(m_arret);
    layoutRadioButton->addWidget(m_arretForce);
    layoutRadioButton->addWidget(m_veilleProlonge);

    m_choixExtinction = new QGroupBox("Choix : ", this);
    m_choixExtinction->setLayout(layoutRadioButton);

    QVBoxLayout *fondPageExtinctionProgramme = new QVBoxLayout(this);
    fondPageExtinctionProgramme->addWidget(m_choixExtinction);
    fondPageExtinctionProgramme->addStretch();  //INSERT UN SPACER

    m_pageExtinctionProgramme->setLayout(fondPageExtinctionProgramme);

    m_tab->addTab(m_pageExtinctionProgramme, "Commande extinction");

    settings.endGroup();
}

void option::PageOption()   //fabrication page
{
    QSettings settings;
    settings.beginGroup("PageOption");

    m_pageOption = new QWidget(this);

    m_affichageVariablesDock = new QLabel("des valeurs horaires enregistr� avant la derni�re fermeture", this);
    QVBoxLayout *layoutGroupActiverAffichage = new QVBoxLayout();
    layoutGroupActiverAffichage->addWidget(m_affichageVariablesDock);

    m_groupActiverAffichage = new QGroupBox("Activer l'affichage", this);
    m_groupActiverAffichage->setCheckable(true);
    m_groupActiverAffichage->setChecked(settings.value("activerAffichageVariablesDock", false).toBool());
    m_groupActiverAffichage->setLayout(layoutGroupActiverAffichage);

    m_labelSon = new QLabel("Activer une information sonore lors de la fin du d�compte", this);

    m_cheminSon = new QLineEdit(this);
    m_cheminSon->setText(settings.value("cheminLectureSon").toString());
    connect(m_cheminSon, SIGNAL(textChanged(QString)), this, SLOT(lectureCheminSonQlineEdit(QString)));

    m_ouvrirFenetreCheminSon = new QToolButton(this);
    connect(m_ouvrirFenetreCheminSon, SIGNAL(clicked()), this, SLOT(lectureCheminSon()));

    QVBoxLayout *fondGroupSon = new QVBoxLayout();
    fondGroupSon->addWidget(m_labelSon);
    QHBoxLayout *layoutCheminSon = new QHBoxLayout();
    layoutCheminSon->addWidget(m_cheminSon);
    layoutCheminSon->addWidget(m_ouvrirFenetreCheminSon);
    fondGroupSon->addLayout(layoutCheminSon);

    m_groupSon = new QGroupBox("Son", this);
    m_groupSon->setLayout(fondGroupSon);
    m_groupSon->setCheckable(true);
    m_groupSon->setChecked(settings.value("lireSon", false).toBool());

    fondPageOption = new QVBoxLayout(this);
    fondPageOption->addWidget(m_groupActiverAffichage);
    fondPageOption->addWidget(m_groupSon);
    fondPageOption->addStretch();

    m_pageOption->setLayout(fondPageOption);

    m_tab->addTab(m_pageOption, "Option");

    settings.endGroup();
}

void option::lectureCheminSon()
{
    QSettings settings;

    QString FichierSon;
    FichierSon = QFileDialog::getOpenFileName(this, "Ouvrir un fichier Son", QString(), "Son (*.wav)");

    settings.setValue("PageOption/cheminLectureSon", FichierSon);
    settings.setValue("PageOption/lireSon", true);  //valide checkbox

    m_cheminSon->setText(FichierSon);
}

void option::lectureCheminSonQlineEdit(QString chemin)  //lors de l'�criture manuel du chemin d'acc�s
{
    QSettings settings;
    settings.setValue("PageOption/cheminLectureSon", chemin);
    settings.setValue("PageOption/lireSon", true);
}

void option::PageSauvegarde(bool boucle)     //fabrication page
{
    QSettings settings;

if(boucle == false) //pour actualisation lors du premier appel � la construction boucle = false puis true
{


    m_pageSauvegarde = new QWidget(this);

    m_tableauSauvegarde = new QTableWidget(this);
    m_tableauSauvegarde->setColumnCount(5);

    QStringList listeHorizontalTableau;
    listeHorizontalTableau << "Nom" << "Date" << "Type" << "Valeur" << "Supprimer";
    m_tableauSauvegarde->setHorizontalHeaderLabels(listeHorizontalTableau);

    connect(m_tableauSauvegarde, SIGNAL(cellChanged(int,int)), this, SLOT(ChangementNomItem(int,int)));
    connect(m_tableauSauvegarde, SIGNAL(cellClicked(int,int)), this, SLOT(OuvertureReglages(int,int)));
    connect(m_tableauSauvegarde, SIGNAL(cellClicked(int,int)), this, SLOT(supprimerItem(int,int)));
    connect(this, SIGNAL(actualisationSignal(bool)), this, SLOT(actualisationSlots(bool)));
}

    int nbRows(0);

    for(int i(0); i < 10; i++)  //compte le nombre de sauvegarde active
    {
        QString stringGroupe, valeur;
        valeur.setNum(i);
        stringGroupe = "sauvegarde" + valeur;

        settings.beginGroup(stringGroupe);

        if(settings.value("enregistrer", false).toBool())   //enregistrer doit �tre = true
        {
            nbRows++;
        }

        settings.endGroup();
    }
    m_tableauSauvegarde->setRowCount(nbRows);

    for(int i(0); i < nbRows; i++)  //mise en page tableau sauvegarde   //rows = ligne
    {
        QString stringGroupe, valeur;
        valeur.setNum(i);
        stringGroupe = "sauvegarde" + valeur;

        settings.beginGroup(stringGroupe);

        for(int j(0); j < 5; j++)   //affichage colonne
        {
            m_sauvegarde[i][j] = new QTableWidgetItem();

            if(j == 0)
            {
                m_sauvegarde[i][j]->setText(settings.value("affichageNom").toString());
                m_tableauSauvegarde->setItem(i, j, m_sauvegarde[i][j]);
            }
            else if(j == 1)
            {
                QDateTime dateTime(settings.value("dateTime").value<QDateTime>());
                m_sauvegarde[i][j]->setText(dateTime.toString("hh:mm:ss dd.MM.yyyy"));
                m_sauvegarde[i][j]->setFlags(Qt::ItemIsEnabled);
                m_tableauSauvegarde->setItem(i, j, m_sauvegarde[i][j]);
            }
            else if(j == 2)
            {
                if(settings.value("horaireChecked").toBool())
                {
                    m_sauvegarde[i][j]->setText("Horaire");
                    m_sauvegarde[i][j]->setFlags(Qt::ItemIsEnabled);
                    m_tableauSauvegarde->setItem(i, j, m_sauvegarde[i][j]);
                }
                else
                {
                    m_sauvegarde[i][j]->setText("Minuteur");
                    m_sauvegarde[i][j]->setFlags(Qt::ItemIsEnabled);
                    m_tableauSauvegarde->setItem(i, j, m_sauvegarde[i][j]);
                }
            }
            else if(j == 3)
            {
                if(settings.value("horaireChecked").toBool())
                {
                    QDateTime dateTime(settings.value("horaire").value<QDateTime>());
                    m_sauvegarde[i][j]->setFlags(Qt::ItemIsEnabled);
                    m_sauvegarde[i][j]->setText(dateTime.toString("hh:mm:ss dd.MM.yyyy"));
                    m_tableauSauvegarde->setItem(i, j, m_sauvegarde[i][j]);
                }
                else
                {
                    QTime time(settings.value("minuterH").toInt(), settings.value("minuterM").toInt(), settings.value("minuterS").toInt());
                    m_sauvegarde[i][j]->setText(time.toString("hh:mm:ss"));
                    m_sauvegarde[i][j]->setFlags(Qt::ItemIsEnabled);
                    m_tableauSauvegarde->setItem(i, j, m_sauvegarde[i][j]);
                }
            }
            else if(j == 4)
            {
                m_sauvegarde[i][j]->setIcon(QIcon("images/delete.png"));
                m_sauvegarde[i][j]->setFlags(Qt::ItemIsEnabled);
                m_tableauSauvegarde->setItem(i, j, m_sauvegarde[i][j]);
            }
        }
        settings.endGroup();
    }

if(boucle == false)
{

    m_fondPageSauvegarde = new QVBoxLayout(this);
    m_fondPageSauvegarde->addWidget(m_tableauSauvegarde);

    m_pageSauvegarde->setLayout(m_fondPageSauvegarde);

    m_tab->addTab(m_pageSauvegarde, "Sauvegarde");
}
}

void option::supprimerItem(int ligne, int colonne)  //slots //Ne fonctionne pas correctement //A voir
{
if(colonne == 4)
{
    int nbRows(0);
    QSettings settings;

    for(int i(0); i < 10; i++)
    {
        QString stringGroupe, valeur;
        valeur.setNum(i);
        stringGroupe = "sauvegarde" + valeur;

        settings.beginGroup(stringGroupe);

        if(settings.value("enregistrer", false).toBool())
        {
            nbRows++;
        }

        settings.endGroup();
    }

    if(nbRows != ligne)
    {
        QString stringGroupe1, valeur1;
        valeur1.setNum(nbRows);
        stringGroupe1 = "sauvegarde" + valeur1;

        QString stringGroupe2, valeur2;
        valeur2.setNum(ligne);
        stringGroupe2 = "sauvegarde" + valeur2;

        //inverse les valeurs, la derni�re sauvegarde dans celle � supprimer
        settings.setValue(stringGroupe2 + "/affichageNom", settings.value(stringGroupe1 + "/affichageNom").toString());
        settings.setValue(stringGroupe2 + "/dateTime", settings.value(stringGroupe1 + "/dateTime").value<QDateTime>());
        settings.setValue(stringGroupe2 + "/horaire", settings.value(stringGroupe1 + "/horaire").value<QDateTime>());
        settings.setValue(stringGroupe2 + "/minuterH", settings.value(stringGroupe1 + "/minuterH").toInt());
        settings.setValue(stringGroupe2 + "/minuterM", settings.value(stringGroupe1 + "/minuterM").toInt());
        settings.setValue(stringGroupe2 + "/minuterS", settings.value(stringGroupe1 + "/minuterS").toInt());
        settings.setValue(stringGroupe2 + "/minuterChecked", settings.value(stringGroupe1 + "/minuterChecked").toBool());
        settings.setValue(stringGroupe2 + "/horaireChecked", settings.value(stringGroupe1 + "/horaireChecked").toBool());
    }

    QString stringGroupe, valeur;
    valeur.setNum(nbRows);
    stringGroupe = "sauvegarde" + valeur;

    settings.beginGroup(stringGroupe);
    settings.setValue("enregistrer", false);    //puis suppression de la derni�re sauvegarde
    settings.endGroup();

    emit actualisationSignal(true); //emet signal actualisation tableau
}
}

void option::OuvertureReglages(int ligne, int colonne)  //ouvre les r�glages puis � la fermeture sauvegarde les valeurs retourn�e
{
    if(colonne == 2 || colonne == 3)
    {
        if(fenetreModificationReglages->exec() == 0)
        {
            QSettings settings;

            QString stringGroupe, valeur;
            valeur.setNum(ligne);
            stringGroupe = "sauvegarde" + valeur;

            settings.beginGroup(stringGroupe);
            settings.setValue("horaire", fenetreModificationReglages->setHoraire());
            settings.setValue("minuterH", fenetreModificationReglages->setMinuterH());
            settings.setValue("minuterM", fenetreModificationReglages->setMinuterM());
            settings.setValue("minuterS", fenetreModificationReglages->setMinuterS());
            settings.setValue("horaireChecked", fenetreModificationReglages->isHoraireChecked());
            settings.setValue("minuterChecked", fenetreModificationReglages->isMinuterChecked());
            settings.endGroup();

            emit actualisationSignal(true); //emet signal actualisation tableau
        }
    }
}

void option::actualisationSlots(bool etat)  //slots
{
    PageSauvegarde(etat);   //true always
}

void option::ChangementNomItem(int ligne, int colonne)  //sauvegarde le nom modifier, directement dans le tableau
{
    QSettings settings;

    if(colonne == 0)
    {
        QString stringGroupe, valeur;
        valeur.setNum(ligne);
        stringGroupe = "sauvegarde" + valeur;

        settings.beginGroup(stringGroupe);
        settings.setValue("affichageNom", m_sauvegarde[ligne][colonne]->text());    //colonne toujours �gale � 0
        settings.endGroup();
    }
}

void option::closeEvent(QCloseEvent *even)  //� la fermeture, sauvegarde les valeurs inscrit dans la fenetre option pour y avoir acc�s lors de la prochaine ouverture du programme
{
    QSettings settings;

    settings.beginGroup("PageOption");
    settings.setValue("activerAffichageVariablesDock", m_groupActiverAffichage->isChecked());
    settings.endGroup();

    settings.beginGroup("pageExtinction");
    settings.setValue("redemarrage", m_redemarrage->isChecked());
    settings.setValue("arret", m_arret->isChecked());
    settings.setValue("arretForce", m_arretForce->isChecked());
    settings.setValue("veilleProlonge", m_veilleProlonge->isChecked());
    settings.endGroup();

    even->accept(); //ferme
}

bool option::isOptionCheckBoxActivateAffichageDock()
{
    return m_groupActiverAffichage->isChecked();
}

option::TypeExtinction option::choixExtinction()    //renvoie ENUM pour connaitre l'action � �ffectu�e
{
    if(m_redemarrage->isChecked())
    {
        return option::redemarrage;
    }
    else if(m_arret->isChecked())
    {
        return option::arret;
    }
    else if(m_arretForce->isChecked())
    {
        return option::arretForce;
    }
    else if(m_veilleProlonge->isChecked())
    {
        return option::veilleProlonge;
    }
}
