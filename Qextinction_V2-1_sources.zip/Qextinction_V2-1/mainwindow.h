/* Qextinction / mainwindow.h
   Copyright (C) 2012 Pierre Leroux

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.*/

#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QtGui/QMainWindow>
#include "inclusion.h"
#include "dockreglages.h"
#include "option.h"

class MainWindow : public QMainWindow
{
    Q_OBJECT
    
public:
    MainWindow(QWidget *parent = 0);
    ~MainWindow();

protected:
    void closeEvent(QCloseEvent *even);

public slots:

    //ouverture fenetre QDialog APropos
    void ouvrirAPropos();

    //Acces fonction Quitter
    void quitter();

    void boutonStartStop();

    void actualisationQLabel();

    void boucleTest();

    void testProgramme();

    void actualisatonDateHeure();

    void EtatBoutonDockStartAndStop(bool etat = false);

    void EtatDock(bool etat = false);

    void affichageSauvegarde();

    void enregistrement();

    void effacerEnregistrement();

    void lectureSauvegarde();

signals:

    void arretOrdinateur();

    //void actualisationEnregistrement();


private:

    QMenu *menuFichier;
    QMenu *menuSauvegarde;  //� l'interieur de fichier
    QMenu *menuOption;
    QMenu *MenuAffichage;
    QMenu *menuAide;

    QAction *actionQuitter;
    QAction *actionReglages;
    QAction *actionAbout;
    QAction *actionAboutQt;
    QAction *actionStartAndStop;
    QAction *actionEtatBoutonDockStartAndStop;
    QAction *actionEtatDock;
    QAction *actionEnregistrement;

    QToolBar *toolBarPrincipal;

    QDockWidget *dockBoutonStartAndStop;
    QPushButton *boutonDockStartAndStop;

    QLabel *dateHeureStatusBar;
    QTimer *interuptionSecondeStatutBar;

    /*// declaration bas de la fen�tre layout vertical integrer dans le principal
    QPushButton *m_aPropos;
    QPushButton *m_quitter;
    QHBoxLayout *layoutSecondaireBas;*/

    /*// declaration widget principaux layout horizontal principal
    QPushButton *m_reglage;
    */QLabel *m_decompte;/*
    QPushButton *m_boutonStartStop;
    QVBoxLayout *m_layoutPrincipal;*/

    /*QWidget *zoneCentrale;*/

    option *fenetreOption;

    dockReglages *dock;

    QMessageBox *message;   //declaration message box fermeture appli

    QTime *m_heureInscrit;
    QDate *m_dateInscrit;

    QTimer *m_Interuption1S;

    bool m_ouvertureReglage;

    bool m_bloquageDecompte;

    void ouvrirMessageBoxBlocageDecompte();

    void writeSetting();

    void readSetting();

    bool isActivateDockButton;
    bool isActivateDock;

};

#endif // MAINWINDOW_H
